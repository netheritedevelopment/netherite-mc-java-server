package org.loomdev.api.entity.monster.illager;

import org.loomdev.api.entity.raid.Raider;

/**
 * Represents a ravager entity.
 */
public interface Ravager extends Raider {
}
