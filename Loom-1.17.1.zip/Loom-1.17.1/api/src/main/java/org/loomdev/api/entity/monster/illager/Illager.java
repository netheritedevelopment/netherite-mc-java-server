package org.loomdev.api.entity.monster.illager;

import org.loomdev.api.entity.raid.Raider;

public interface Illager extends Raider {
}
