package org.loomdev.api.entity.monster.piglin;

/**
 * Represents a piglin brute entity.
 */
public interface PiglinBrute extends AbstractPiglin {
}
