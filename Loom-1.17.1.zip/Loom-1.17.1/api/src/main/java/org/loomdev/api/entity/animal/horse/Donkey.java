package org.loomdev.api.entity.animal.horse;

public interface Donkey extends ChestedHorse {
}
