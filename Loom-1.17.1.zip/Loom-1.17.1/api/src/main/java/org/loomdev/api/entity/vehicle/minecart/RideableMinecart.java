package org.loomdev.api.entity.vehicle.minecart;

/**
 * Represents a minecart that can be ridden by an entity.
 */
public interface RideableMinecart extends Minecart {
}
