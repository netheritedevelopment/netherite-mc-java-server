package org.loomdev.api.entity.projectile;

/**
 * Represents a FishBobber entity.
 */
public interface FishingHook extends Projectile {
}
