package org.loomdev.api.entity.animal.horse;

import org.loomdev.api.entity.animal.horse.Llama;

/**
 * Represents a trader llama entity.
 */
public interface TraderLlama extends Llama {
}
