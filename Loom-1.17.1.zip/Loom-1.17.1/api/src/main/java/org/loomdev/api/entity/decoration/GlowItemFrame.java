package org.loomdev.api.entity.decoration;

public interface GlowItemFrame extends ItemFrame {
}
