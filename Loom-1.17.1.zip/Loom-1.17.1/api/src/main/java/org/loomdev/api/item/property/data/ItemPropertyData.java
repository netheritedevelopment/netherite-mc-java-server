package org.loomdev.api.item.property.data;

public interface ItemPropertyData<T extends ItemPropertyData<T>> extends Cloneable {
}
