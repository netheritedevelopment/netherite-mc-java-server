package org.loomdev.api.entity.animal.fish;

public interface Cod extends SchoolingFish {
}
