package org.loomdev.api.entity.ambient;

import org.loomdev.api.entity.monster.MobEntity;

public interface AmbientEntity extends MobEntity {
}
