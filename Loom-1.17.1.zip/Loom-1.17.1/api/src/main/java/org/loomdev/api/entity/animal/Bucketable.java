package org.loomdev.api.entity.animal;

public interface Bucketable {

    void setFromBucket(boolean flag);
}
