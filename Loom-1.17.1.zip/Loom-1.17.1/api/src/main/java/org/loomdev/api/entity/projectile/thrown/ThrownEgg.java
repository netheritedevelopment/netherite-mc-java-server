package org.loomdev.api.entity.projectile.thrown;

/**
 * Represents an egg entity.
 */
public interface ThrownEgg extends ThrowableItem {
}
