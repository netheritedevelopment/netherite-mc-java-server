package org.loomdev.api.entity.misc;

import org.loomdev.api.entity.Entity;

public interface Marker extends Entity {
}
