package org.loomdev.api.entity.monster;

import org.loomdev.api.entity.raid.Raider;

/**
 * Represents a witch entity.
 */
public interface Witch extends Raider {
}
