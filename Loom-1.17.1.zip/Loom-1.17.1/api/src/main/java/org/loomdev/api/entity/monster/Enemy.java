package org.loomdev.api.entity.monster;

// TODO should this extend entity?
public interface Enemy {
}
