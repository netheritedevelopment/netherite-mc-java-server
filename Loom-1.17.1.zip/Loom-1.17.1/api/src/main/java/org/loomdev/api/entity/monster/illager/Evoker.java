package org.loomdev.api.entity.monster.illager;

import org.loomdev.api.entity.monster.illager.SpellcastingIllager;

public interface Evoker extends SpellcastingIllager {
}
