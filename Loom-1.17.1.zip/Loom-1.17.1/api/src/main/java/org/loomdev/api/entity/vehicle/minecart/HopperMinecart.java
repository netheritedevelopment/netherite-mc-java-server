package org.loomdev.api.entity.vehicle.minecart;

/**
 * Represents a minecart with a hopper inside.
 */
public interface HopperMinecart extends StorageMinecart {
}
