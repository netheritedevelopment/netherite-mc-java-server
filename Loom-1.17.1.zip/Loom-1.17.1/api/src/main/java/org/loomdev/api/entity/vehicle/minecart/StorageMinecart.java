package org.loomdev.api.entity.vehicle.minecart;

/**
 * Represents a storage minecart.
 */
public interface StorageMinecart extends Minecart {
    // TODO inventory
}
