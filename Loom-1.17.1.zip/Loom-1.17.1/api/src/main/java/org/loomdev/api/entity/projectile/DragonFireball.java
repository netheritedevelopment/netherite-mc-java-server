package org.loomdev.api.entity.projectile;

public interface DragonFireball extends AbstractFireball {
}
