package org.loomdev.api.entity.animal;

import org.loomdev.api.entity.Saddleable;

/**
 * Represents a pig entity.
 */
public interface Pig extends Animal, Saddleable {
    // TODO possible add things todo with the stick steering item
}
