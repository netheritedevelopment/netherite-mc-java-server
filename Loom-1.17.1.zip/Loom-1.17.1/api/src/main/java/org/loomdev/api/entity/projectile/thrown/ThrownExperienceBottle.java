package org.loomdev.api.entity.projectile.thrown;

/**
 * Represents an experience bottle entity.
 */
public interface ThrownExperienceBottle extends ThrowableItem {
}
