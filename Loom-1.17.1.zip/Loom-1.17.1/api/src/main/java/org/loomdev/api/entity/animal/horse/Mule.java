package org.loomdev.api.entity.animal.horse;

public interface Mule extends ChestedHorse {
}
