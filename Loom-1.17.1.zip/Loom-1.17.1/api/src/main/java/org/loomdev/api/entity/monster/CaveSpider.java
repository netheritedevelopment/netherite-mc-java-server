package org.loomdev.api.entity.monster;

public interface CaveSpider extends Spider {
}
