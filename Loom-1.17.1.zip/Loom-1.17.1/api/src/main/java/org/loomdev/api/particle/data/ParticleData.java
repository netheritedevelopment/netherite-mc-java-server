package org.loomdev.api.particle.data;

public interface ParticleData {
}
