package org.loomdev.api.entity.monster;

import org.loomdev.api.entity.monster.Monster;

/**
 * Represents a silverfish entity.
 */
public interface Silverfish extends Monster {
}
