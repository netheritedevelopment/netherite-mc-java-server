package org.loomdev.api.entity.vehicle.minecart;

/**
 * Represents a minecart with a furnace inside.
 */
public interface FurnaceMinecart extends Minecart {
    // TODO inventory
}
