package org.loomdev.api.entity.decoration;

import org.loomdev.api.entity.Entity;
import org.loomdev.api.util.Attachable;

public interface HangingEntity extends Entity, Attachable {
}
