package org.loomdev.api.entity.projectile;

public interface AbstractFireball extends ExplosiveProjectile {
}
