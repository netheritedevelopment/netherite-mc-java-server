package org.loomdev.api.entity.monster.skeleton;

/**
 * Represents a stray entity.
 * <p>Variant of {@link AbstractSkeleton}</p>
 */
public interface Stray extends AbstractSkeleton {
}
