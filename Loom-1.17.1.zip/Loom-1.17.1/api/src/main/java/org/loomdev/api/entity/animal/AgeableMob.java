package org.loomdev.api.entity.animal;

import org.loomdev.api.entity.monster.PathableMob;

public interface AgeableMob extends PathableMob {
}
