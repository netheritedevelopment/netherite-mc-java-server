package org.loomdev.api.entity.animal;

public interface Sittable {

    boolean isSitting();

    void setSitting(boolean sitting);
}
