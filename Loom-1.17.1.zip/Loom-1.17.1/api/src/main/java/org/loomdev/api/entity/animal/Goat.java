package org.loomdev.api.entity.animal;

public interface Goat extends Animal {

    boolean isScreamingGoat();

    void setScreamingGoat(boolean flag);
}
