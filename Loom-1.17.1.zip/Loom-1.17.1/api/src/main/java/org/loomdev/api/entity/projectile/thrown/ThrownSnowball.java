package org.loomdev.api.entity.projectile.thrown;

/**
 * Represents a snowball entity.
 */
public interface ThrownSnowball extends ThrowableItem {
}
