package org.loomdev.api.entity.animal.horse;

import org.loomdev.api.entity.animal.horse.AbstractHorse;

/**
 * Represents a skeleton horse entity.
 */
public interface SkeletonHorse extends AbstractHorse {
}
