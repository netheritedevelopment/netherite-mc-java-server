package org.loomdev.api.entity.monster.skeleton;

/**
 * Represents a skeleton entity.
 */
public interface Skeleton extends AbstractSkeleton {
}
