package org.loomdev.api.entity.monster.zombie;

import org.loomdev.api.entity.monster.Monster;

public interface Giant extends Monster {
}
