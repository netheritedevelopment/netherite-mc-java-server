package org.loomdev.api.entity.monster.zombie;

public interface Drowned extends Zombie {
}
