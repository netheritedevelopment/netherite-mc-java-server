package org.loomdev.api.entity.projectile;

public interface ExplosiveProjectile extends Projectile {
}
