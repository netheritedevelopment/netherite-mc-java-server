package org.loomdev.api.entity.monster.illager;

import org.loomdev.api.entity.monster.illager.Illager;

/**
 * Represents a vindicator entity.
 */
public interface Vindicator extends Illager {
}
