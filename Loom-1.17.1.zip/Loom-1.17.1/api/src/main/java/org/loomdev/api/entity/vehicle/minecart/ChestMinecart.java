package org.loomdev.api.entity.vehicle.minecart;

/**
 * Represents a minecart with a chest inside.
 */
public interface ChestMinecart extends StorageMinecart {
}
