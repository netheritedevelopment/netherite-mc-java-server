package org.loomdev.api.entity.animal;

public interface Cow extends Animal {
}
