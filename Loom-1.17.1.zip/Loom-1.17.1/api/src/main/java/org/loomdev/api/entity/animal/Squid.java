package org.loomdev.api.entity.animal;

import org.loomdev.api.entity.monster.WaterAnimal;

/**
 * Represents a Squid entity.
 */
public interface Squid extends WaterAnimal {
}
