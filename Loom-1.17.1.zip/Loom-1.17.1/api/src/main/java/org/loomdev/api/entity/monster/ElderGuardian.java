package org.loomdev.api.entity.monster;

import org.loomdev.api.entity.monster.Guardian;

public interface ElderGuardian extends Guardian {
}
