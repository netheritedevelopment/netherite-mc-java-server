package org.loomdev.api.entity.animal;

public interface Ocelot extends Animal {
}
