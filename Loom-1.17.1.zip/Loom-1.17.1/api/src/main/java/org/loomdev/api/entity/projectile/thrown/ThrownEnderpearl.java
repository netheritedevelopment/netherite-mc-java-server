package org.loomdev.api.entity.projectile.thrown;

/**
 * Represents an ender pearl entity.
 */
public interface ThrownEnderpearl extends ThrowableItem {
}
