package org.loomdev.api.entity.projectile.thrown;

/**
 * Represents a potion entity.
 */
public interface ThrownPotion extends ThrowableItem {
}
