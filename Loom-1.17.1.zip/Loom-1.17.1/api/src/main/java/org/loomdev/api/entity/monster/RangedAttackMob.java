package org.loomdev.api.entity.monster;

public interface RangedAttackMob {
}
