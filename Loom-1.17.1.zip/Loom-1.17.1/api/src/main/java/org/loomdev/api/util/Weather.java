package org.loomdev.api.util;

public enum Weather {
    CLEAR,
    RAIN,
    THUNDER
}
