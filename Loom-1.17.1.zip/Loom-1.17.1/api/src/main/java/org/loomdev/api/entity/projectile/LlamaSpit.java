package org.loomdev.api.entity.projectile;

public interface LlamaSpit extends Projectile {
}
