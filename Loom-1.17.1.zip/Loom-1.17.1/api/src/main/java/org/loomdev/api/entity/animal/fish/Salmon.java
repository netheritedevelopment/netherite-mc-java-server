package org.loomdev.api.entity.animal.fish;

/**
 * Represents a salmon entity.
 */
public interface Salmon extends SchoolingFish {
}
