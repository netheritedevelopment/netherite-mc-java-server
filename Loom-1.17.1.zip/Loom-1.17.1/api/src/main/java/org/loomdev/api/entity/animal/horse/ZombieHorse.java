package org.loomdev.api.entity.animal.horse;

import org.loomdev.api.entity.animal.horse.AbstractHorse;

/**
 * Represents a zombie horse entity.
 */
public interface ZombieHorse extends AbstractHorse {
}
