package org.loomdev.api.entity.projectile;

public interface SmallFireball extends Fireball {
}
