package org.loomdev.api.entity.monster.zombie;

public interface Husk extends Zombie {
}
