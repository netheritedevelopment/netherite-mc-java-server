package org.loomdev.api.entity.monster.illager;

import org.loomdev.api.entity.monster.RangedAttackMob;

public interface Illusioner extends SpellcastingIllager, RangedAttackMob {
}
