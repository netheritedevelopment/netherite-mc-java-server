package org.loomdev.api.entity.animal;

public interface GlowSquid extends Squid {

    int getDarkTicks();

    void setDarkTicks(int ticks);
}
