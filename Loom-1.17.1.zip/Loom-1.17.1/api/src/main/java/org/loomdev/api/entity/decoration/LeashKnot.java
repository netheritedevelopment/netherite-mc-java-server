package org.loomdev.api.entity.decoration;

public interface LeashKnot extends HangingEntity {
}
