package org.loomdev.api.entity.projectile.thrown;

import org.loomdev.api.entity.projectile.AbstractArrow;

/**
 * Represents a trident entity.
 */
public interface ThrownTrident extends AbstractArrow {
}
