package org.loomdev.api.entity.animal.golem;

import org.loomdev.api.entity.monster.PathableMob;

public interface Golem extends PathableMob {
}
