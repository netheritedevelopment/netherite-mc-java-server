package org.loomdev.api.command;

public interface ConsoleCommandSource extends CommandSource {
}
