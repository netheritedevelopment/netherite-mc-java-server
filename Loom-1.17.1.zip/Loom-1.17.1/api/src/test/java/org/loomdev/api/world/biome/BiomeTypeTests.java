package org.loomdev.api.world.biome;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.loomdev.api.helpers.RegistryTestCase;

public class BiomeTypeTests extends RegistryTestCase {

    @Test
    @Disabled
    public void checkItemTypesAgainstMC() {
        // TODO
        // LoomAssert.fieldsAgainstMCRegistry(BiomeType.class, Registry.BIOME_KEY);
    }
}
