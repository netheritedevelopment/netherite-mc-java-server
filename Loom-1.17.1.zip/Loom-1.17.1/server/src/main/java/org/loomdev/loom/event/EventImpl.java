package org.loomdev.loom.event;

import org.loomdev.api.event.Event;

public class EventImpl implements Event {
}
